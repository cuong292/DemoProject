package com.example.demoproject.base;

public class BaseModel {
}
