package com.example.demoproject.base;

public class BaseView {
}
